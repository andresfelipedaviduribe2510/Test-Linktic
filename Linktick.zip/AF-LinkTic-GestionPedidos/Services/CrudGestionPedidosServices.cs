﻿using AF_LinkTic_GestionPedidos.Domain.Interfaces;
using AF_LinkTic_GestionPedidos.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AF_LinkTic_GestionPedidos.Services
{
    public class CrudGestionPedidosServices
    {
        private readonly IClienteService _clienteService;
        private readonly IGetCliente _getCliente;
        private readonly IUpdateClienteService _updateClienteService;
        private readonly IGetPedidosPorClientesService _pedidosPorClientesService;
        private readonly IInsertPedidosService _insertPedidosService;
        private readonly IUpdatePedidoService _updatePedidoService;
        private readonly IGetPedido _getPedido;
        public CrudGestionPedidosServices(IClienteService clienteService, IGetCliente getCliente, IUpdateClienteService updateClienteService, IGetPedidosPorClientesService pedidosPorClientesService, IInsertPedidosService insertPedidosService,
            IUpdatePedidoService updatePedidoService, IGetPedido getPedido)
        {
            _clienteService = clienteService;
            _getCliente = getCliente;
            _updateClienteService = updateClienteService;
            _pedidosPorClientesService = pedidosPorClientesService;
            _insertPedidosService = insertPedidosService;
            _updatePedidoService = updatePedidoService;
            _getPedido = getPedido;
        }

        public async Task<Result<bool>> InsertCliente(string name, string descripcion, string direccion, string telefono)
        {
            try
            {
                var insertSuccess = await _clienteService.InsertCliente(name, descripcion, direccion, telefono);

                if (insertSuccess)
                {
                    return new Result<bool>
                    {
                        Message = "Se han insertado los clientes exitosamente.",
                        Success = true
                    };
                }
                else
                {
                    return new Result<bool>
                    {
                        Message = "La inserción del cliente falló.",
                        Success = false
                    };
                }
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Message = $"Algo salió mal: {ex.Message}",
                    Success = false
                };
            }
        }
        public Task<Result<List<GetClientes>>> GetCliente()
        {
            var result = _getCliente.GetCliente();
            return result;
        }

        public async Task<Result<bool>> UpdateCliente(int clienteID, string nombre, string email, string direccion, string telefono)
        {
            var result = await _updateClienteService.UpdateCliente(clienteID, nombre, email, direccion, telefono);

            return result;
        }

        public Task<Result<List<GetPedidosPorClientes>>> GetPedidosPorClientes()
        {
            var result = _pedidosPorClientesService.GetPedidosPorClientes();
            return result;
        }

        public async Task<Result<bool>> InsertPedidos(int clienteID, DateTime fechaPedido, string estado, decimal total)
        {
            try
            {
                var insertSuccess = await _insertPedidosService.InsertPedidos(clienteID, fechaPedido, estado, total);

                if (insertSuccess)
                {
                    return new Result<bool>
                    {
                        Message = "El pedido se ha insertado exitosamente.",
                        Success = true
                    };
                }
                else
                {
                    return new Result<bool>
                    {
                        Message = "La inserción del pedido falló.",
                        Success = false
                    };
                }
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Message = $"Algo salió mal: {ex.Message}",
                    Success = false
                };
            }
        }

        public async Task<Result<bool>> UpdatePedido(int pedidoID, int clienteID, DateTime fechaPedido, string estado, decimal total)
        {
            try
            {
                var updateSuccess = await _updatePedidoService.UpdatePedido(pedidoID, clienteID, fechaPedido, estado, total);

                if (updateSuccess)
                {
                    return new Result<bool>
                    {
                        Message = "El pedido se ha actualizado exitosamente.",
                        Success = true
                    };
                }
                else
                {
                    return new Result<bool>
                    {
                        Message = "La actualización del pedido falló.",
                        Success = false
                    };
                }
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Message = $"Algo salió mal: {ex.Message}",
                    Success = false
                };
            }
        }

        public async Task<Result<List<GetPedidos>>> GetPedidos(int? pedidoId = null)
        {
            try
            {
                var result = pedidoId.HasValue
                    ? await _getPedido.GetPedido(pedidoId.Value)
                    : await _getPedido.GetPedido();

                if (result == null || !result.Success)
                {
                    return new Result<List<GetPedidos>>
                    {
                        Message = "Fallo el servicio",
                        Success = false
                    };
                }

                return result;
            }
            catch (Exception ex)
            {
                return new Result<List<GetPedidos>>
                {
                    Message = ex.Message,
                    Success = false
                };
            }
        }
        public async Task<Result<GetOrderDetailsDto>> GetOrderDetails(int pedidoId)
        {
            try
            {
                // Obtener el pedido por ID
                var pedidoResult = await _getPedido.GetPedido(pedidoId);

                if (pedidoResult == null || !pedidoResult.Success)
                {
                    return new Result<GetOrderDetailsDto>
                    {
                        Message = "Pedido no encontrado.",
                        Success = false
                    };
                }

                var pedido = pedidoResult.Data; // Asumiendo que `Data` es un objeto de tipo GetPedidos

                // Obtener los detalles del cliente asociado al pedido

                    return new Result<GetOrderDetailsDto>
                    {
                        Message = "Cliente no encontrado.",
                        Success = false
                    };

            }
            catch (Exception ex)
            {
            }
        }

    }
}
