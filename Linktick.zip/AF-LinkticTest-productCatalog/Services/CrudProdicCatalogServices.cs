﻿using AF_LinkticTest_productCatalog.Domain.Interfaces;
using AF_LinkticTest_productCatalog.Domain.Models;
using AF_LinkticTest_productCatalog.Infrastructure.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace AF_LinkticTest_productCatalog.Services
{
    public class CrudProdicCatalogServices
    {
        private readonly IInsertDataProducCatalog _insertDataProducCatalog;
        private readonly IGetDataCategoria _getDataCategoria;
        private readonly IUpdateDataCategoria _updateDataCategoria;
        private readonly IGetDataProductoPorCategoria _getDataProductoPorCategoria;
        private readonly IInsertDataProducto _insertDataProducto;
        private readonly IUpdateProducto _updateProducto;
        public CrudProdicCatalogServices(IInsertDataProducCatalog insertDataProducCatalog, IGetDataCategoria getDataCategoria, IUpdateDataCategoria updateDataCategoria, 
            IGetDataProductoPorCategoria getDataProductoPorCategoria, IInsertDataProducto insertDataProducto, IUpdateProducto updateProducto)
        {
            _insertDataProducCatalog = insertDataProducCatalog;
            _getDataCategoria = getDataCategoria;
            _updateDataCategoria = updateDataCategoria;
            _getDataProductoPorCategoria = getDataProductoPorCategoria;
            _insertDataProducto = insertDataProducto;
            _updateProducto = updateProducto;
        }

        public async Task<Result<bool>> InsertData(string name, string descripcion)
        {
            try
            {
                var insertSuccess = await _insertDataProducCatalog.insertData(name, descripcion);

                if (insertSuccess)
                {
                    return new Result<bool>
                    {
                        Message = "Se han insertado las categorías exitosamente.",
                        Success = true
                    };
                }
                else
                {
                    return new Result<bool>
                    {
                        Message = "La inserción de la categoría falló.",
                        Success = false
                    };
                }
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Message = $"Algo salió mal: {ex.Message}",
                    Success = false
                };
            }
        }
        public Task<Result<List<GetCategoria>>> GetData()
        {
            var result = _getDataCategoria.GetData();
            return result;
        }

        public async Task<Result<bool>> UpdateData(int categoriaID, string name, string description)
        {
            var result = await _updateDataCategoria.UpdateData(categoriaID, name, description);
            return result;
        }

        public Task<Result<List<GetProductosPorCategoria>>> GetDataProductosPorCategoria()
        {
            var result = _getDataProductoPorCategoria.GetDataProductoPorCategoria();
            return result;
        }

        public async Task<Result<bool>> InsertDataByProducto(string nombre, string descripcion, decimal precio, int stock, int categoriaID)
        {
            try
            {
                var insertSuccess = await _insertDataProducto.insertDataByProducto(nombre, descripcion, precio, stock, categoriaID);

                if (insertSuccess)
                {
                    return new Result<bool>
                    {
                        Message = "Se han insertado los productos exitosamente.",
                        Success = true
                    };
                }
                else
                {
                    return new Result<bool>
                    {
                        Message = "La inserción del producto falló.",
                        Success = false
                    };
                }
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Message = $"Algo salió mal: {ex.Message}",
                    Success = false
                };
            }
        }
        public async Task<Result<bool>> UpdateProducto(int productoID, string nombre, string descripcion, decimal precio, int stock, int categoriaID)
        {
            var result = await _updateProducto.UpdateData(productoID, nombre, descripcion, precio, stock, categoriaID);
            return result;
        }
    }
}
