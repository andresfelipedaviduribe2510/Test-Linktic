﻿using AF_LinkticTest_productCatalog.Services;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using System;
using AF_LinkticTest_productCatalog.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;

namespace AF_LinkticTest_productCatalog
{
    public class CrudProdicCatalog
    {
        private readonly CrudProdicCatalogServices _crudProdicCatalogServices;
        private readonly ILogger<CrudProdicCatalog> _logger;
        public CrudProdicCatalog(CrudProdicCatalogServices crudProdicCatalogServices, ILogger<CrudProdicCatalog> logger)
        {
            _crudProdicCatalogServices = crudProdicCatalogServices;
            _logger = logger;
        }

        [FunctionName("InsertData")]
        public async Task<IActionResult> InsertData(
           [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<InsertDataProducCatalog>(requestBody);

            if (input == null || string.IsNullOrEmpty(input.name))
            {
                return new BadRequestObjectResult("El nombre de la categoría es obligatorio.");
            }

            var res = await _crudProdicCatalogServices.InsertData(input.name, input.description);
            return new OkObjectResult(res);
        }

        [FunctionName("GetData")]
        public async Task<Result<List<GetCategoria>>> GetData(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
           ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            var res = await _crudProdicCatalogServices.GetData();

            return res;
        }

        [FunctionName("UpdateData")]
        public async Task<IActionResult> UpdateData(
            [HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateDataProductCatalog>(requestBody);

            if (input == null || input.CategoriaID <= 0 || string.IsNullOrEmpty(input.Name))
            {
                return new BadRequestObjectResult("El ID de la categoría y el nombre son obligatorios.");
            }

            var res = await _crudProdicCatalogServices.UpdateData(input.CategoriaID, input.Name, input.Description);
            return new OkObjectResult(res);
        }


        [FunctionName("GetDataProductosPorCategoria")]
        public async Task<Result<List<GetProductosPorCategoria>>> GetDataProductosPorCategoria(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
           ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            var res = await _crudProdicCatalogServices.GetDataProductosPorCategoria();

            return res;
        }

        [FunctionName("InsertDataByProductos")]
        public async Task<IActionResult> InsertDataByProductos(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<InsertDataProducto>(requestBody);

            if (input == null || string.IsNullOrEmpty(input.Nombre) || input.Precio <= 0 || input.Stock < 0 || input.CategoriaID <= 0)
            {
                return new BadRequestObjectResult("Todos los campos son obligatorios y deben tener valores válidos.");
            }

            var res = await _crudProdicCatalogServices.InsertDataByProducto(input.Nombre, input.Descripcion, input.Precio, input.Stock, input.CategoriaID);
            return new OkObjectResult(res);
        }

        [FunctionName("UpdateProducto")]
        public async Task<IActionResult> UpdateProducto(
            [HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request for product update.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateProducto>(requestBody);

            if (input == null || input.ProductoID <= 0 || string.IsNullOrEmpty(input.Nombre) || input.Precio <= 0 || input.Stock < 0 || input.CategoriaID <= 0)
            {
                return new BadRequestObjectResult("Todos los campos son obligatorios y deben tener valores válidos.");
            }

            var result = await _crudProdicCatalogServices.UpdateProducto(input.ProductoID, input.Nombre, input.Descripcion, input.Precio, input.Stock, input.CategoriaID);

            return new OkObjectResult(result);
        }



    }
}
