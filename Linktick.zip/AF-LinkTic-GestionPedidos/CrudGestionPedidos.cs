﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AF_LinkTic_GestionPedidos.Domain.Models;
using AF_LinkTic_GestionPedidos.Services;

namespace AF_LinkTic_GestionPedidos
{
    public class CrudGestionPedidos
    {

        private readonly CrudGestionPedidosServices _crudGestionPedidosServices;
        private readonly ILogger<CrudGestionPedidos> _logger;

        public CrudGestionPedidos(ILogger<CrudGestionPedidos> logger, CrudGestionPedidosServices crudGestionPedidosServices)
        {
            _logger = logger;
            _crudGestionPedidosServices = crudGestionPedidosServices;
        }
        [FunctionName("InsertClientes")]
        public async Task<IActionResult> InsertClientes(
          [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<InsertClientes>(requestBody);

            if (input == null || string.IsNullOrEmpty(input.Nombre))
            {
                return new BadRequestObjectResult("El nombre del cliente es obligatorio.");
            }

            var res = await _crudGestionPedidosServices.InsertCliente(input.Nombre, input.Email, input.Direccion, input.Telefono);
            return new OkObjectResult(res);
        }

        [FunctionName("GetClientes")]
        public async Task<Result<List<GetClientes>>> GetData(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
           ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            var res = await _crudGestionPedidosServices.GetCliente();

            return res;
        }

        [FunctionName("UpdateClientes")]
        public async Task<IActionResult> UpdateClientes(
            [HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdateClientes>(requestBody);

            if (input == null || input.ClienteID <= 0 || string.IsNullOrEmpty(input.Nombre))
            {
                return new BadRequestObjectResult("El ID del cliente y el nombre son obligatorios.");
            }

            var res = await _crudGestionPedidosServices.UpdateCliente(input.ClienteID, input.Nombre, input.Email, input.Direccion, input.Telefono);

            return new OkObjectResult(res);
        }



        [FunctionName("GetPedidosPorClientes")]
        public async Task<Result<List<GetPedidosPorClientes>>> GetDataProductosPorCategoria(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
           ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            var res = await _crudGestionPedidosServices.GetPedidosPorClientes();

            return res;
        }

        [FunctionName("InsertPedido")]
        public async Task<IActionResult> InsertPedido(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<InsertPedido>(requestBody);

            if (input == null || input.ClienteID <= 0 || input.Total <= 0 || string.IsNullOrEmpty(input.Estado))
            {
                return new BadRequestObjectResult("Todos los campos son obligatorios y deben tener valores válidos.");
            }

            var res = await _crudGestionPedidosServices.InsertPedidos(input.ClienteID, input.FechaPedido, input.Estado, input.Total);
            return new OkObjectResult(res);
        }


        [FunctionName("UpdatePedido")]
        public async Task<IActionResult> UpdatePedido(
            [HttpTrigger(AuthorizationLevel.Anonymous, "put", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var input = JsonConvert.DeserializeObject<UpdatePedido>(requestBody);

            if (input == null || input.PedidoID <= 0 || input.ClienteID <= 0 || input.FechaPedido == default || string.IsNullOrEmpty(input.Estado) || input.Total <= 0)
            {
                return new BadRequestObjectResult("Todos los campos son obligatorios y deben tener valores válidos.");
            }

            var res = await _crudGestionPedidosServices.UpdatePedido(input.PedidoID, input.ClienteID, input.FechaPedido, input.Estado, input.Total);
            return new OkObjectResult(res);
        }

        public async Task<Result<List<GetPedidos>>> GetPedidos(int? pedidoId = null)
        {
            try
            {
                var result = await _crudGestionPedidosServices.GetPedidos(pedidoId);

                if (result == null || !result.Success)
                {
                    return new Result<List<GetPedidos>>
                    {
                        Success = false,
                        Message = "Algo salió mal, revisar el servicio"
                    };
                }

                return result;
            }
            catch (Exception ex)
            {
                return new Result<List<GetPedidos>>
                {
                    Success = false,
                    Message = ex.Message
                };
            }
        }



        [FunctionName("GetOrderDetails")]
        public async Task<IActionResult> GetOrderDetails(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "orders/{pedidoId}")] HttpRequest req,
           ILogger log, int pedidoId)
        {
            log.LogInformation($"Request to get details for order {pedidoId} received.");

            try
            {
                var result = await _crudGestionPedidosServices.GetOrderDetails(pedidoId);

                if (result == null)
                {
                    log.LogWarning($"No details found for order {pedidoId}.");
                    return new NotFoundObjectResult($"No details found for order {pedidoId}.");
                }

                return new OkObjectResult(result);
            }
            catch (Exception ex)
            {
                log.LogError($"An error occurred while getting order details: {ex.Message}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }


    }
}
