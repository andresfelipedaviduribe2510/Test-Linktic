﻿using AF_LinkticTest_productCatalog.Domain.Interfaces;
using AF_LinkticTest_productCatalog.Infrastructure.GenericRepository;
using AF_LinkticTest_productCatalog.Infrastructure.Repository;
using AF_LinkticTest_productCatalog.Services;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(AF_LinkticTest_productCatalog.Startup))]

namespace AF_LinkticTest_productCatalog
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            // Registro de servicios en el contenedor de DI
            builder.Services.AddScoped<CrudProdicCatalogServices>();
            builder.Services.AddScoped<IDataAccessRepository, GenericRepository>();
            builder.Services.AddScoped<IInsertDataProducCatalog, InsertDataRepository>();
        }
    }
}
